Please do well to read this for how to use these framework:

//buttons
Buttons - btn-1

//accordions - beta
accordion - acc-1

//bg-background, txt-text, bd-border color
colors - bg-, txt-, bd
//for shadows
shadows: shadow-1

//containers
container-md

//rows
rows: row, row-cols-1, row-cols-xl-1

//columns
columns: col, col-1, col-md-2

//cards
card: card-1

//display
display: d-inline-block

//float
float: float-end

//height
height: h-50

//width
width: w-25

//padding
padding: p-1, p-xl-2

//margin
margin: m-1, m-xl-2

//positioning
position: positon-fixed

//gutters
gutter: gx-1(horizontal axis), gy-1(vertical axis), g-1(both)

/beta
input: in-progress

